package com.example.homework1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Course_information extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_information);
    }
}
